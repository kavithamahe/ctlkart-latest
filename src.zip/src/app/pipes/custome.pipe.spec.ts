import { CustomePipe } from './custome.pipe';

describe('CustomePipe', () => {
  it('create an instance', () => {
    const pipe = new CustomePipe();
    expect(pipe).toBeTruthy();
  });
});
