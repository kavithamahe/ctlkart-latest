export const environment = {
  production: true,
  apiUrl : 'http://192.168.1.27:3000/api/',
  imageUrl:'http://192.168.1.27:3000/'
};
